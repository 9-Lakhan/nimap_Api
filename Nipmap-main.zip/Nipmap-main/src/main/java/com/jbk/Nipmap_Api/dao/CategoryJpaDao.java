package com.jbk.Nipmap_Api.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jbk.Nipmap_Api.entity.Category;

public interface CategoryJpaDao extends JpaRepository<Category, Integer>{

}
