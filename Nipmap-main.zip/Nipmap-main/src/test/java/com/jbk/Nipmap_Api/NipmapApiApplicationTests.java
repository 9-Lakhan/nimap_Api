package com.jbk.Nipmap_Api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NipmapApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
